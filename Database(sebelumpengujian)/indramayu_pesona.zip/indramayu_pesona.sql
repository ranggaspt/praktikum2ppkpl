-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Des 2021 pada 15.04
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indramayu_pesona`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `budaya`
--

CREATE TABLE `budaya` (
  `idbudaya` int(10) NOT NULL,
  `nama` text NOT NULL,
  `deskripsi` text NOT NULL,
  `lokasi` text NOT NULL,
  `event` text NOT NULL,
  `gambar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `budaya`
--

INSERT INTO `budaya` (`idbudaya`, `nama`, `deskripsi`, `lokasi`, `event`, `gambar`) VALUES
(1, 'TRADISI NGAROT', '<p><strong>Tradisi Ngarot</strong> adalah upacara adat yang terdapat di Desa Lelea, Kecamatan Lelea, Jawa Barat. Tradisi ini memiliki arti ucapan syukur terhadap datangnya musim tanam. Upacara ini biasanya dilaksanakan pada minggu ketiga bulan November atau Desember dan selalu pada hari Rabu. Hal ini dilakukan karena hari Rabu dianggap keramat dan hari yang baik untuk menanam padi.</p>\r\n\r\n<p>Ngarot berasal dari bahasa Sunda yang berarti minum. Sedangkan dalam bahasa Sansekerta &ldquo;Ngaruat&rdquo; yang berarti bebas dari kutukan dewa, atau bebas dari segala dosa. Budaya Ngarot pertama kali dirintis Ki Buyut Kapol, yaitu seorang tokoh yang loyal dan berpengaruh di Desa Lelea. Ia rela memberikan sawah seluas 26.100 m2 sebagai wujud realisasi acara Ngarot dan dengan sangat senang masyarakat Lelea menyambutnya. Upacara ini biasanya dilakukan oleh pemuda-pemudi warga desa Lelea.</p>\r\n\r\n<p>Upacara Ngarot terdiri dari tiga bagian yaitu arak-arakan, seserahan dan pesta pertunjukan. Peserta yang mengikuti upacara Ngarot harus menggunakan pakaian khas, yaitu remaja putri menggunakan kebaya berselendang dilengkapi aksesoris seperti kalung, gelang, cincin, bros, peniti emas, dan hiasan rambut. Sedangkan remaja putra menggunakan baju komboran dan celana gombrang beserta ikat kepala.</p>\r\n\r\n<p>Upacara dimulai jam 08.30 dan semua peserta Ngarot berkumpul di rumah Kepala Desa untuk didandani. Kemudian pemuda-pemudi diarak mengelilingi kampung. Setelah itu peserta Ngarot masuk balai desa dan disambut dengan tari-tarian daerah.</p>\r\n\r\n<p>Lalu masuk ke inti acara, dimulai dari pembukaan, pembacaan sejarah Ngarot, ucapan sambutan dari Kepala Desa, dan proses penyerahan kepada para kasinoman atau pemuda-pemudi.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15859.095287045036!2d108.23625527833681!3d-6.423099925644281!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6ec7fb4adc405f%3A0x21b66cf02ffef936!2sLelea%2C%20Kec.%20Lelea%2C%20Kabupaten%20Indramayu%2C%20Jawa%20Barat!5e0!3m2!1sid!2sid!4v1638794990823!5m2!1sid!2sid', 'Bulan November atau Desember', 'Ngarot.jpg'),
(2, 'NADRAN KARANGSONG', '<p style=\"text-align:justify\"><strong>Nadran</strong> atau pesta laut ini merupakan hajat masyarakat nelayan, upacara adat para nelayan di indramayu bertujuan untuk mensyukuri hasil tangkapan ikan, dan mengharapkan peningkatan hasil pada tahun mendatang serta berdo&rsquo;a agar tidak mendapat aral melintang dalam mencari nafkah di laut.</p>\r\n\r\n<p style=\"text-align:justify\">Nadran sebenarnya merupakan suatu tradisi hasil akulturasi budaya islam dan hindu yang diwariskan sejak ratusan tahun secara turun-temurun. kata nadran sendiri, menurut sebagian masyarakat, berasal dari kata nazar yang mempunyai makna dalam agama islam: pemenuhan janji. adapun inti upacara nadran adalah mempersembahkan sesajen (yang merupakan ritual dalam agama hindu untuk menghormati roh leluhurnya) kepada penguasa laut agar diberi limpahan hasil laut, sekaligus merupakan ritual tolak bala (keselamatan). sesajen yang diberikan yang berupa anjungan berbentuk replika perahu yang berisi kepala kerbau, kembang tujuh rupa, buah-buahan, makanan khas, dan lain sebagainya. sebelum dilepaskan ke laut.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.6718961077704!2d108.36627251466514!3d-6.306766563476291!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6ebc48002c5bc9%3A0x5de51761c8467dbe!2sPantai%20Karang%20Song!5e0!3m2!1sid!2sid!4v1638881949582!5m2!1sid!2sid', 'Satu Tahun Sekali', 'pelaksaan-nadran-yang-dilakukan-oleh-para-nelayan-bubu-atau-rajungan.jpg'),
(3, 'NGUNJUNG BUYUT ', '<p><strong>Tradisi Ngunjung Buyut</strong> merupakan upacara syukuran yang dilaksanakan di kuburan-kuburan yang dianggap keramat. Ngunjung berarti kunjung atau mengunjungi. Tradisi ini untuk memohon keselamatan dan mengingat nilai-nilai atau pesan dari leluhur. Upacara ini biasanya menampilkan kesenian yang khas, seperti &nbsp;tari-tarian dan wayang cepak.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5689.801127789018!2d108.3194924898591!3d-6.314094728162238!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6ebb8535ce1215%3A0x2b7f6f2bb1c0e94a!2sMakam%20ki%20jaka%20tarub!5e0!3m2!1sid!2sid!4v1638882836065!5m2!1sid!2sid', 'Bulan Syuro Mulud', 'TIRTOID-antarafoto-ngunjung-buyut-gading-261016-da-5.jfif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kuliner`
--

CREATE TABLE `kuliner` (
  `idkuliner` int(11) NOT NULL,
  `nama` text NOT NULL,
  `deskripsi` text NOT NULL,
  `lokasi` text NOT NULL,
  `harga` text NOT NULL,
  `gambar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kuliner`
--

INSERT INTO `kuliner` (`idkuliner`, `nama`, `deskripsi`, `lokasi`, `harga`, `gambar`) VALUES
(1, 'Blengep Cotot ', '<p style=\"text-align:justify\"><strong>Blengep Cotot </strong>merupakan kudapan legendaris khas Indramayu. Bahannya terbuat dari singkong yang direbus, lalu ditumbuk hingga bisa dibentuk menjadi bulatan-bulatan pipih berdiameter sekitar 8cm yang didalamnya diisi gula. Setiap bulatan diolesi dengan minyak goreng agar tidak menempel satu sama lain.</p>\r\n\r\n<p style=\"text-align:justify\">Kudapan ini selalu ditemukan di pasar tradisional di Indramayu. Namun yang paling legendaris dan kerap disebut-sebut identik dengan blengep cotot adalah Pasar Bangkir, Desa Rambatan Kulon, Kecamatan Lohbener, Indramayu.</p>\r\n\r\n<p style=\"text-align:justify\">Nama Blengep Cotot sendiri berasal dari 3 kata, yakni &#39;bleng&#39;, &#39;lep&#39; dan &#39;cotot&#39;. Bleng merupakan istilah makanan ketika masuk ke dalam mulut. Lep merupakan istilah makanan ketika lidah menyahut makanan tersebut. Kedua istilah itu kemudian dijadikan sebagai Blengep.</p>\r\n\r\n<p style=\"text-align:justify\">Adapun untuk istilah Cotot, adalah ketika mulut mengunyah gula merah yang ada di dalam kue tersebut. Bagi orang Indramayu, hal tersebut dinamakan Cotot. Karena itulah, kue tradisional tersebut dinamakan Blengep Cotot.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.1243195167144!2d108.29121779704843!3d-6.377949122507529!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6eb8f8ffffffff%3A0x60ef0b51acb8a917!2sPasar%20Bangkir!5e0!3m2!1sid!2sid!4v1638795293193!5m2!1sid!2sid', 'Rp. 1.000/buah', 'Blengep Cotot.jpg'),
(2, 'PINDANG GOMBYANG ', '<p><strong>Pindang Gombyang</strong>&nbsp;merupakan makanan khas dari Indramayu yang&nbsp;bercita rasa gurih, pedas, dan sedikit masam ini memang menjadi buruan saat berkunjung ke daerah berjuluk Kota Mangga tersebut.</p>\r\n\r\n<p>Pindang gombyang dibuat dari bagian kepala ikan manyung yang berukuran cukup besar.&nbsp;Kepala ikan berukuran besar tersebut kemudian dibelah menjadi dua bagian setelah melalui proses pemindangan, yaitu pengolahan tradisional dengan cara dikukus dengan rempah.</p>\r\n\r\n<p>Untuk menghasilkan pindang gombyang yang sedap, perlu digunakan beberapa rempah pendukung di kuahnya yaitu campurkan untuk bahan dasar kuah adalah kunyit, jahe, bawang merah, bawang putih, lengkuas, kemiri, kacang tanah, asem jawa, tomat, dan cabai rawit. Semuanya dimasukkan jadi satu, hingga kepala ikan berwarna kekuningan matang sampai siap untuk disajikan.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7931.1934283367145!2d108.35592603488767!3d-6.3165872!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6ebc192011d4cd%3A0xa2f0167e308171f2!2spanorama%20restaurant!5e0!3m2!1sid!2sid!4v1638883495002!5m2!1sid!2sid', 'Rp. 50.000/porsi', '026028800_1550325815-Pindang_Gombyang.jpg'),
(3, 'CIMPLO(APEM) ', '<p><strong>Cimplo&nbsp;</strong>merupakan kue yang berbentuk bundar dan berwarna putih ini terkenal sebagai kue yang unik karena hanya dihidangkan satu tahun sekali oleh masyarakat kota mangga tersebut. Kue Cimplo ini mirip dengan kue apem. Cimplo juga terbuat dari tepung beras dan tape singkong yang membuat cita rasanya khas. Kue tersebut memiliki tekstur yang lembut serta tawar gurih yang menggugah selera.</p>\r\n\r\n<p>Yang unik dari kue Cimplo tersebut adalah cara memakannya yang menggunakan tambahan gula merah cair dengan parutan kelapa. Berbeda dengan kue apem yang biasanya dimakan langsung, cimplo oleh masyarakat Indramayu akan disajikan hangat bersama gula merah cair sebagai pendamping.</p>\r\n\r\n<p>Terdapat kepercayaan dari masyarakat Indramayu jika kue tersebut dapat digunakan sebagai &ldquo;penawar&rdquo; dari tolak bala. Cimplo biasanya disajikan satu tahun sekali saat bulan saffar. Menurut kepercayaan setempat, bulan Saffar merupakan bulan bala yang mana saat itu Allah menurunkan 1000 macam penyakit ke bumi dan diperuntukkan bagi manusia. Sehingga jangan heran jika sedang berkunjung ke Indramayu di bulan Oktober. Kita akan sering menyaksikan para ibu rumah tangga membuat kudapan tradisional tersebut secara ngariung atau ramai-ramai.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1015344.7699492931!2d106.60709640615052!3d-6.2386143848249125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f1bb309b4e3a7%3A0x212a4d7afce3f2db!2sWarung%20Cimplo!5e0!3m2!1sid!2sid!4v1638883775416!5m2!1sid!2sid', 'Rp. 15.000/tepak', 'Cimplo.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tentang`
--

CREATE TABLE `tentang` (
  `idtentang` int(10) NOT NULL,
  `nama` text NOT NULL,
  `deskripsi` text NOT NULL,
  `tgambar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tentang`
--

INSERT INTO `tentang` (`idtentang`, `nama`, `deskripsi`, `tgambar`) VALUES
(1, 'Pesona Indramayu       ', '<p style=\"text-align:justify\"><strong>Kabupaten Indramayu</strong> merupakan kabupaten yang memiliki julukan sebagai Kota Mangga lantaran di wilayahnya banyak sekali buah mangga dan menjadi salah satu daerah penghasil mangga terbesar di Indonesia. Selain dikenal sebagai daerah penghasil buah mangga, Indramayu juga punya potensi wisata, budaya, dan kuliner yang yang unik yang dapat menarik banyak wisatawan untuk berkunjung.</p>\r\n\r\n<p style=\"text-align:justify\">Oleh Karena itu, dengan adanya website <strong>Pesona Indramayu&nbsp;</strong>wisatawan dapat dimudahkan untuk mencari berbagai informasi seputar&nbsp;wisata, budaya, dan kuliner yang berada di Kabupaten Indramayu.</p>\r\n', 'foto.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`email`, `username`, `password`) VALUES
('rangga@gmail.com', 'Rangga Saputra', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Struktur dari tabel `wisata`
--

CREATE TABLE `wisata` (
  `idwisata` int(10) NOT NULL,
  `nama` text NOT NULL,
  `deskripsi` text NOT NULL,
  `lokasi` text NOT NULL,
  `tiket` text NOT NULL,
  `gambar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `wisata`
--

INSERT INTO `wisata` (`idwisata`, `nama`, `deskripsi`, `lokasi`, `tiket`, `gambar`) VALUES
(1, 'PANTAI KARANGSONG  ', '<p style=\"text-align:justify\"><strong>Pantai Karangsong&nbsp;</strong>merupakan kawasan pantai utara tepatnya berada di Desa Karangsong, Kecamatan Indramayu, Kabupaten Indramayu, Provinsi Jawa Barat.&nbsp;Pantai ini memiliki pasir yang hitam, namun begitu halus dan nyaman. Tidak terhalang juga oleh batuan karang sehingga wisatawan dapat memandang lautan lepas. Air laut meskipun tak tampak biru, namun begitu jernih.</p>\r\n\r\n<p style=\"text-align:justify\">Ombak lautan pun tidak terlalu tinggi, sehingga banyak wisatawan yang bermain di air laut. Ada yang berenang di tepian pantai, ada juga yang membawa pelampung untuk bermain. Tidak hanya itu, ada juga yang membawa perahu karet untuk bermain di tepian pantai. Perahu-perahu pun siap untuk disewa untuk menjelajah wilayah perairan.</p>\r\n\r\n<p style=\"text-align:justify\">Wilayah pasirnya begitu luas, dan tentunya terjaga kebersihannya. Di bagian belakang tepi pantai, terdapat pepohonan selain pohon mangrove. Sehingga pantai tampak begitu teduh dengan pepohonan tersebut. Wisatawan pun tampak nyaman menikmati waktu di pantai.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.679604276127!2d108.3672381100149!3d-6.30575882347863!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6ebc4872ce9051%3A0x488988f64087588f!2sPantai%20Karangsong!5e0!3m2!1sid!2sid!4v1638794556979!5m2!1sid!2sid', ' Rp. 5.000/motor dan Rp. 10.000/mobil', 'karangsong.jpg'),
(2, 'WATU BUBUT CIWADO ', '<p style=\"text-align:justify\"><strong>Watu Bubut Ciwado</strong> merupakan wisata alam yang berada di Desa Cikawung, Kecamatan Terisi, Kabupaten Indramayu. Tempat wisata ini belum banyak diketahui orang, karena objek wisata Watu Bubut Ciwado baru dibuka oleh BKPH Cikamurang yang bekerjasama dengan LMDH Hutan Makmur.</p>\r\n\r\n<p style=\"text-align:justify\">Wisata alam Ciwado yang indah dan menawan yang terletak di tengah kawasan hutan Jati, di wilayah perbatasan antara Kabupaten Indramayu &ndash; Sumedang. Selain menawarkan eksotisme alam di sekitar, pengunjung juga bisa menikmati pemandangan alam dari ketinggian Puncak Bukit Ciwado.</p>\r\n\r\n<p style=\"text-align:justify\">Bagi wisatawan yang baru pertama kali berkunjung ke Wisata Alam Bukit Ciwado ini akan merasa kagum melihat pemandangan alam yang sangat indah menawan dan asri alami.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15851.87079031211!2d107.98865156643096!3d-6.650925939067916!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e692d84ca284ed1%3A0x74f16d133cb47869!2sWisata%20Alam%20WATU%20BUBUT%20CIWADO!5e0!3m2!1sid!2sid!4v1638880871932!5m2!1sid!2sid', 'Rp. 10.000/orang', 'ciwado.jpg'),
(3, 'ARGOWISATA SITU BOLANG ', '<p style=\"text-align:justify\"><strong>Agrowisata Situ Bolang</strong>&nbsp;merupakan kawasan wisata perkebunan yang memiliki daya tarik tersendiri,&nbsp;karena di kawasan wisata Agrowisata Situ Bolang wisatawan dapat menyejukkan mata bahkan pikiran dengan melihat ratusan pohon mangga dan banyak menawarkan objek wisata lainnya.</p>\r\n\r\n<p style=\"text-align:justify\">Hal yang menjadi keunikan dari tepat wisata ini. Karena adanya pohon mangga jenis Agrimania yang biasanya mangga jenis ini tumbuh di daratan tinggi. Dengan penanganan yang ahli dan dirawat oleh tangan yang ahli maka pohon mangga jenis Agrimania dapat tumbuh dengan baik meski di daratan rendah sekalipun.</p>\r\n\r\n<p style=\"text-align:justify\">Pada Awalnya Agrowisata Situ Bolang ini dibuat untuk memajukan perekonomian daerah dalam bidang pertanian. Hingga ada usulan ide bagaimana caranya membuat kebun sekaligus dijadikan tempat wisata yang dapat menghasilkan pemasukan untuk daerah. Sekaligus ingin mengenalkan buah mangga Agrimania kepada publik.</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.8860297144424!2d108.19095551477082!3d-6.5360748952724785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6ecf00604e8031%3A0x9a314d4aedad73d8!2sAGROWISATA%20SITU%20BOLANG!5e0!3m2!1sid!2sid!4v1638881425812!5m2!1sid!2sid', 'Rp. 10.000/orang', 'Pintu Gerbang Obyek Wisata Situ Bolang.jpg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `budaya`
--
ALTER TABLE `budaya`
  ADD PRIMARY KEY (`idbudaya`);

--
-- Indeks untuk tabel `kuliner`
--
ALTER TABLE `kuliner`
  ADD PRIMARY KEY (`idkuliner`);

--
-- Indeks untuk tabel `tentang`
--
ALTER TABLE `tentang`
  ADD PRIMARY KEY (`idtentang`);

--
-- Indeks untuk tabel `wisata`
--
ALTER TABLE `wisata`
  ADD PRIMARY KEY (`idwisata`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `budaya`
--
ALTER TABLE `budaya`
  MODIFY `idbudaya` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kuliner`
--
ALTER TABLE `kuliner`
  MODIFY `idkuliner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tentang`
--
ALTER TABLE `tentang`
  MODIFY `idtentang` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `wisata`
--
ALTER TABLE `wisata`
  MODIFY `idwisata` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
